<?php
define('BASE_URL', "http://localhost/tp2");
define('DB_HOST', 'localhost');
define('DB_NAME', 'recuperatorios');
// define('DB_NAME', 'abc');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

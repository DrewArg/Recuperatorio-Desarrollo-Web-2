<footer>
    <div class="footer">
        <p>Andrés Ezequiel Fabbiano</p>
        <p>2022</p>
        <p>Analista de Sistemas</p>
    </div>
</footer>
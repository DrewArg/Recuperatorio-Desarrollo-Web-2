<header>
<?php require('../layout/_nav.php') ?>
</header>
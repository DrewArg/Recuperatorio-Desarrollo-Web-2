<nav class="topNav">
    <a href="<?php echo BASE_URL; ?>/index.php">Home</a>
    <a href="<?php echo BASE_URL; ?>/pages/shop.php">Tienda</a>
    <a href="<?php echo BASE_URL; ?>/pages/rules.php">Reglamento</a>
    <a href="<?php echo BASE_URL; ?>/pages/contact.php">Contacto</a>
</nav>